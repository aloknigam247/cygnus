var namespaces =
[
    [ "cystructs", "namespacecystructs.html", null ]
];