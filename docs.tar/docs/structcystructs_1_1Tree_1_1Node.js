var structcystructs_1_1Tree_1_1Node =
[
    [ "Node", "structcystructs_1_1Tree_1_1Node.html#ab649b2c9aabb310806485eb12407557b", null ],
    [ "data", "structcystructs_1_1Tree_1_1Node.html#ab4ac2e1011bfa09aad1a55c351b44ba2", null ],
    [ "left", "structcystructs_1_1Tree_1_1Node.html#a30bd9ec89066a622c95f586e7e794003", null ],
    [ "right", "structcystructs_1_1Tree_1_1Node.html#a4a8c1842d9cc1be7d14513c645605119", null ]
];