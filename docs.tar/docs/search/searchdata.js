var indexSectionsWithContent =
{
  0: "abcdegilopstuvw~",
  1: "cilotv",
  2: "c",
  3: "clo",
  4: "abdegiopstuvw~",
  5: "t",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "enums",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Enumerations",
  6: "Friends"
};

