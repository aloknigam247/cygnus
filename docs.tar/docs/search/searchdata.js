var indexSectionsWithContent =
{
  0: "abcdegilnopstuvw~",
  1: "ilotv",
  2: "n",
  3: "c",
  4: "clo",
  5: "abdeginopstuvw~",
  6: "t",
  7: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "structs",
  3: "namespaces",
  4: "files",
  5: "functions",
  6: "enums",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Structs",
  3: "Modules",
  4: "Files",
  5: "Operations",
  6: "Enumerations",
  7: "Friends"
};

