var searchData=
[
  ['w',['w',['../classLog.html#ab99fa6768b3be441cf4306830d63798b',1,'Log']]]
];
