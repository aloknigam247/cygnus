var searchData=
[
  ['log_21',['Log',['../classLog.html',1,'']]],
  ['log_2eh_22',['Log.h',['../Log_8h.html',1,'']]]
];
