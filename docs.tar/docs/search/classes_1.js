var searchData=
[
  ['log_44',['Log',['../classLog.html',1,'']]]
];
