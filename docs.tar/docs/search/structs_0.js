var searchData=
[
  ['node_50',['Node',['../structcystructs_1_1Tree_1_1Node.html',1,'cystructs::Tree']]]
];
