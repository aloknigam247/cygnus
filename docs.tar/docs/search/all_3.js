var searchData=
[
  ['d_6',['d',['../classLog.html#a97e2b1b81a165f3d42f47cf02bffde54',1,'Log']]],
  ['display_7',['display',['../classLog.html#a7012423badd120f7a81cfb5eddf69bd2',1,'Log::display(T pi_first, Args... pi_args)'],['../classLog.html#a1300c47b964c9bdbd1f99db9c731654b',1,'Log::display()']]]
];
