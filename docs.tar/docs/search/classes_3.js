var searchData=
[
  ['log',['Log',['../classLog.html',1,'']]]
];
