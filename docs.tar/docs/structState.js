var structState =
[
    [ "finalState", "structState.html#a95aee282e646b4e9b1839325a20db99f", null ],
    [ "sym", "structState.html#a06d4bf07cbd12aaf65b1eb1484006889", null ],
    [ "tag", "structState.html#a4cb29eda3b256b8c101c5841effe8b51", null ]
];