var classNFA =
[
    [ "addPattern", "classNFA.html#a30c6bcb76eb9030a38e0ae90b97eaaf3", null ],
    [ "addTransition", "classNFA.html#a9bd42cb0b3c98dcee5fde56fa72057b6", null ],
    [ "addTransition", "classNFA.html#a029db091e6302123d003c70e35c1d6f2", null ],
    [ "compile", "classNFA.html#a674e0ba482a23893ad07f441a18d936e", null ],
    [ "execute", "classNFA.html#aa054918f2095bc10b65326f5691f91fa", null ],
    [ "get_table", "classNFA.html#a4aa2eddbd81bd86a1df27c54a2b4d9a2", null ],
    [ "printGraph", "classNFA.html#adf1a4ed2b8726f37317342cab701244b", null ],
    [ "printTable", "classNFA.html#a9109b4a72c08eb1cb2bb5a2044801f51", null ]
];