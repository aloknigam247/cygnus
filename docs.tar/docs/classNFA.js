var classNFA =
[
    [ "addPattern", "classNFA.html#a30c6bcb76eb9030a38e0ae90b97eaaf3", null ],
    [ "addTransition", "classNFA.html#a9bd42cb0b3c98dcee5fde56fa72057b6", null ],
    [ "addTransition", "classNFA.html#a029db091e6302123d003c70e35c1d6f2", null ],
    [ "build", "classNFA.html#ae9a4a10713bf007f23f56ca6b8e582c5", null ],
    [ "get_table", "classNFA.html#a4aa2eddbd81bd86a1df27c54a2b4d9a2", null ],
    [ "printDot", "classNFA.html#adb14f46e7b22a1085862ffb87d7adec7", null ],
    [ "printTable", "classNFA.html#a9109b4a72c08eb1cb2bb5a2044801f51", null ],
    [ "table", "classNFA.html#ac2b7c8d388c28da4d4fbe8f794b17ce5", null ]
];