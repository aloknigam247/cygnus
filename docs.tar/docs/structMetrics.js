var structMetrics =
[
    [ "is_filled", "structMetrics.html#adf2cfc4cef031b780c3bbfefe5cc34b7", null ],
    [ "len", "structMetrics.html#a0f201039b5ce3e7dc6557080bf4d8480", null ],
    [ "max_len", "structMetrics.html#a015b2861c95d6d8cad9d2ac2eec5ec04", null ]
];