var structStateEntry =
[
    [ "Transition", "structStateEntry_1_1Transition.html", "structStateEntry_1_1Transition" ],
    [ "StateEntry", "structStateEntry.html#a65456160581f9aad86e627af5b078c32", null ],
    [ "is_final", "structStateEntry.html#a3e373a97ac7c6b9b3ed8457fad7b5ca8", null ],
    [ "tag", "structStateEntry.html#af9958e4790441029865931d4dfc20d8b", null ],
    [ "transition_list", "structStateEntry.html#a317bd0e00b8ca562ea22b0c956c73ee7", null ]
];