var classOption =
[
    [ "Value", "unionOption_1_1Value.html", "unionOption_1_1Value" ],
    [ "Type", "classOption.html#ab1ccd1400a3eb7bfa5b56279216b242e", [
      [ "BOOL", "classOption.html#ab1ccd1400a3eb7bfa5b56279216b242ea1c800d30824427a294c154c936ec7dc4", null ],
      [ "CHAR", "classOption.html#ab1ccd1400a3eb7bfa5b56279216b242eab88cda97617e9671e437fd77a49014a4", null ],
      [ "INT", "classOption.html#ab1ccd1400a3eb7bfa5b56279216b242eac13174c034679854412a0374463ca958", null ],
      [ "STRING", "classOption.html#ab1ccd1400a3eb7bfa5b56279216b242ea2ffb4de27aec16cdbc7dbf943c651e50", null ]
    ] ],
    [ "Option", "classOption.html#ac3a3e02245835486a34fb13e70fc6a8b", null ],
    [ "get_bool_value", "classOption.html#a76300074a00bc3977260d2a95d7ad676", null ],
    [ "get_char_value", "classOption.html#a940ee29f2f0b53fa6c5d60c636394b49", null ],
    [ "get_help", "classOption.html#abdb310b542104ab152e006a3cec7cce1", null ],
    [ "get_int_value", "classOption.html#a172cbf26d30ee78b4382bcee10772330", null ],
    [ "get_name", "classOption.html#a477c15cfa2a2a8d447e2ed5363865d86", null ],
    [ "get_string_value", "classOption.html#a797c2821ffe61649a1052cd4cc38bbf9", null ],
    [ "get_type", "classOption.html#a3ea0f04afdd15c14bbb87b2bee9928a2", null ],
    [ "operator==", "classOption.html#a6db4a679267250833904d9010ba920dc", null ],
    [ "operator>", "classOption.html#a7cc1f30f604e6b18669a121b15e8db06", null ],
    [ "operator>", "classOption.html#ae4070e80a47840b07978b53e18294373", null ],
    [ "set_value", "classOption.html#a88d928c1fd719a5f5c633f6d7056fe58", null ],
    [ "set_value", "classOption.html#a47936bae47d9bbf74734959cf0433a00", null ],
    [ "set_value", "classOption.html#a5a95a307b0041c42f2ac48e9c030c747", null ],
    [ "set_value", "classOption.html#a86e744e4ae1feb9fa1b964cfc6b6604b", null ],
    [ "help", "classOption.html#a80ba3c5709f313200d4156752d3d77af", null ],
    [ "name", "classOption.html#a6a8657a431831defbd5fccefa41dbd3d", null ],
    [ "type", "classOption.html#a04ea4c260b2f0fc1e60c1fc2f19f4c28", null ],
    [ "value", "classOption.html#a511f099c85f6aa9a4b417e9bb61c07dd", null ]
];